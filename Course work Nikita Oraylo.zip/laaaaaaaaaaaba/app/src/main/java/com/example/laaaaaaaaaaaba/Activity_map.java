package com.example.laaaaaaaaaaaba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Activity_map extends AppCompatActivity {

    int location;       //номер бутика с edit text с прошлой страницы
    ImageView image;    // переменная с типом Image view
    Button btn;         // переменная с типом button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        image = findViewById(R.id.image);               // ищем image по id

        Bundle arguments = getIntent().getExtras();       //функция для получения данных с прошлой страницы по ключу

        location = Integer.parseInt(arguments.get("location").toString());     // данные с прошлой страницы прикрепляем к переменной location

        btn = findViewById(R.id.button2);         // ищем кнопку по id в коде xml




         if (location == 4) {                                  // в зависимости от введенного номера бутика меняем изображение на image view
             image.setImageResource(R.drawable.mega_mall_4);
         }
         else if (location == 1) {
             image.setImageResource(R.drawable.mega_mall_1);
         }
         else if (location == 2) {
             image.setImageResource(R.drawable.mega_mall_2);
         }
         else if (location == 3) {
             image.setImageResource(R.drawable.mega_mall_3);
         }
         else if (location == 5) {
             image.setImageResource(R.drawable.mega_mall_5);
         }
         else if (location == 6) {
             image.setImageResource(R.drawable.mega_mall_6);
         }

         btn.setOnClickListener(                  // кнопка назад. устанавливаем на нее слушатель кликов по кнопке
                 new View.OnClickListener() {
                     @Override
                     public void onClick(View view) {
                         Intent intent2 = new Intent(getApplicationContext(),MainActivity.class);    // создаем intetnt. Это функция для перехода на другие страницы. В данном случае переходим на страницу Main Activity
                         startActivity(intent2);    // запускаем интент созданный выше
                     }
                 }
         );



    }

}